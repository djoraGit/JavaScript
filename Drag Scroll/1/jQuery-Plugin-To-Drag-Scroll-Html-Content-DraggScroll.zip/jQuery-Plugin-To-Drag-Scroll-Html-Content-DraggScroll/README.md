JQuery-DraggScroll
==================

A JQuery extension for making the contents of a container scrollable by clicking and dragging.
