bootstrap3-datatables-editable
==============================

Active development of this plugin is at https://github.com/jphustman/jquery-datatables-editable


