"use strict";

let describe = global.describe;
let it = global.it;

var assert = require('assert');

describe.skip('test loading library with different configs', function () {

    it('webpack', function() {
    });

    it('browserify', function() {
    });

    it('requirejs', function() {
    });

    it('iife', function() {
    });
    
});