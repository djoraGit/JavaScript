/**
 * interact.js {VERSION}
 *
 * Copyright (c) 2012-{YEAR} Taye Adeyemi <dev@taye.me>
 * Released under the MIT License.
 * https://raw.github.com/taye/interact.js/master/LICENSE
 */
